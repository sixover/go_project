# go-pprof-practice

[《golang pprof 实战》](https://blog.wolfogre.com/posts/go-ppof-practice/)代码实验用例。
